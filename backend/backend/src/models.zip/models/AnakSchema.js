const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user',
        required: true,
    },
    
    namaLengkap: {
        type: String,
        required: [true, 'Nama lengkap harus diisi'],
    },

    kelas: {
        type: String,
        required: [true, 'Kelas harus diisi'],
    },
    
    tanggalLahir: {
        type: Date,
        required: true,
    },

    // ⭐⭐ TAMBAH FIELD JENIS KELAMIN ⭐⭐
    jenisKelamin: {
        type: String,
        required: [true, 'Jenis kelamin harus diisi'],
        enum: {
            values: ['L', 'P'],
            message: 'Jenis kelamin {VALUE} tidak valid'
        }
    },

    kondisi_khusus: {
        type: String,
        required: false,
    },

    alamat : {
        type: String,
        required: [true, 'Alamat harus diisi'],
    },
    
}, {
    timestamps: true
});

const Anak = mongoose.model('anak', Schema);
module.exports = Anak;