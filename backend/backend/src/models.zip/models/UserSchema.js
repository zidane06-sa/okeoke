const mongoose = require('mongoose');

// Daftar peran (roles) yang diizinkan sesuai diagram
const validRoles = [
    "ORANG_TUA", 
    "GURU", 
    "ADMIN", 
];

const UserSchema = new mongoose.Schema({
    
    // 2. username
    username: {
        type: String,
        required: [true, 'Nama Lengkap wajib diisi'],
        unique: true, // Pastikan username tidak ada yang sama
        trim: true,
        minlength: 3
    },

    // 3. passwordHash
    // Menyimpan hash (bukan password aslinya)
    passwordHash: {
        type: String,
        required: [true, 'Password hash wajib diisi']
    },

    // 4. email
    email: {
        type: String,
        required: [true, 'Email wajib diisi'],
        unique: true, // Pastikan email tidak ada yang sama
        trim: true,
        lowercase: true, // Simpan email dalam huruf kecil
        // Validator regex sederhana untuk email
        match: [/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/, 'Format email tidak valid']
    },

    noTelfon: {
        type: String,
        required: [true, 'Nomor telepon wajib diisi'],
        trim: true,
    },

    // 5. role
    role: {
        type: String,
        required: [true, 'Role wajib diisi'],
        enum: {
            values: validRoles,
            message: 'Role {VALUE} tidak valid' 
        },
        default: "ORANG_TUA" // Contoh default role
    }
}, {
    // Schema Options
    timestamps: true // Otomatis menambahkan 'createdAt' dan 'updatedAt' (tipe Date)
});

// --- Menambahkan Methods (Implementasi operasi login/logout) ---

// Diagram UML juga mencantumkan fungsi login() dan logout().
// Di Mongoose, ini diimplementasikan sebagai 'methods' pada schema.

// UserSchema.methods.login = function() {
//     // Logika aplikasi untuk proses login, biasanya tidak diimplementasikan di model Mongoose
//     // Implementasi ini biasanya ada di service layer atau controller.
// };

// UserSchema.methods.logout = function() {
//     // Logika aplikasi untuk proses logout
// };

// Contoh Mongoose method (misalnya untuk membandingkan password saat login):
UserSchema.methods.comparePassword = function(candidatePassword) {
    // *Catatan Penting*: Fungsi ini harus menggunakan library hashing seperti bcrypt
    // Contoh: return bcrypt.compare(candidatePassword, this.passwordHash);
    console.log(`Logika perbandingan password untuk user ${this.username}`);
    return true; // Placeholder
};

const User = mongoose.model('User', UserSchema);

module.exports = User;