const mongoose = require('mongoose');

// 1. Define the Schema
// A Mongoose Schema defines the structure of the documents 
// within a MongoDB collection.
const Schema = new mongoose.Schema({

    anakId: { 
    type: mongoose.Schema.Types.ObjectId,
    ref: 'anak',
    required: true
    },

    aktivitas_harian: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'rencanaPembelajaran',
    required: true,
    }],

    anakId: { 
    type: mongoose.Schema.Types.ObjectId,
    ref: 'anak',
    required: true
    },

    catatankhusus: {
        type: String,
        required: false,
    },

    // Field 2: Price (Number, Required)
    tanggal: {
        type: Date,
        required: [true, 'A product must have a price'],
        // min: [0, 'Price must be a non-negative number']
    },
    
    // Field 3: Description (String, Optional)
    catatanAktivitas: {
        type: String,
        required: false,
        // default: 'No description provided.'
    },

        // Field 3: Description (String, Optional)
    fotoKegiatanURL: {
        type: String,
        required: true,
        // default: 'No description provided.'
    },
}, {
    // Schema Options (Optional, but useful)
    timestamps: true // Adds two fields: 'createdAt' and 'updatedAt' automatically
});

// 2. Create the Model
// A Mongoose Model is a class used to construct documents 
// and interact with the MongoDB database collection.
const LaporanHarian = mongoose.model('laporanHarian', Schema);

// 3. Export the Model
module.exports = LaporanHarian;