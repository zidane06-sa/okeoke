const mongoose = require('mongoose');

// 1. Define the Schema
// A Mongoose Schema defines the structure of the documents 
// within a MongoDB collection.
const Schema = new mongoose.Schema({
    
    anak:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'anak',
        required: true,
    },

    judulKegiatan: {
        type: String,
        required: true,
        // default: 'No description provided.'
    },

    tanggal: {
        type: Date,
        required: true,
    }
}, {
    // Schema Options (Optional, but useful)
    timestamps: true // Adds two fields: 'createdAt' and 'updatedAt' automatically
});

// 2. Create the Model
// A Mongoose Model is a class used to construct documents 
// and interact with the MongoDB database collection.
const RencanaPembelajaran = mongoose.model('rencanaPembelajaran', Schema);

// 3. Export the Model
module.exports = RencanaPembelajaran;