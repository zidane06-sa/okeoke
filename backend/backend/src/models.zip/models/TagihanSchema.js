const mongoose = require('mongoose');

// 1. Define the Schema
// A Mongoose Schema defines the structure of the documents 
// within a MongoDB collection.
const Schema = new mongoose.Schema({

    anak:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'anak',
        required: true,
    },

    

    // Field 2: Price (Number, Required)
    nominal: {
        type: Number,
        required: [true, 'A product must have a price'],
        // min: [0, 'Price must be a non-negative number']
    },
    
    // Field 3: Description (String, Optional)
    tanggalJatuhTempo: {
        type: Date,
        required: true,
        // default: 'No description provided.'
    },

    periode: {
        type: String,
        required: [true, 'Periode harus diisi'],
        // default: 'No description provided.'
    },

    tanggalPembayaran: {
        type: Date,
        required: false,
        // default: 'No description provided.'
    },

    status: {
        type: String,
        required: [true, 'Status harus diisi'],
        // default: 'No description provided.'
    },
}, {
    // Schema Options (Optional, but useful)
    timestamps: true // Adds two fields: 'createdAt' and 'updatedAt' automatically
});

// 2. Create the Model
// A Mongoose Model is a class used to construct documents 
// and interact with the MongoDB database collection.
const Tagihan = mongoose.model('tagihan', Schema);

// 3. Export the Model
module.exports = Tagihan;