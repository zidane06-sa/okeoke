const mongoose = require('mongoose');

// 1. Define the Schema
// A Mongoose Schema defines the structure of the documents 
// within a MongoDB collection.
const Schema = new mongoose.Schema({
    
    inventaris: {
        type: mongoose.Schema.Types.ObjectId,
        ref : 'inventaris',
        required: true,
    },

    namaBarang: {
        type: mongoose.Schema.Types.String,
        required: [true, 'A product must have a name'],

    },
    // Field 2: Price (Number, Required)
    deskripsiPekerjaan: {
        type: String,
        required: [true, 'A product must have a price'],
        // min: [0, 'Price must be a non-negative number']
    },
    
    // Field 3: Description (String, Optional)
    tanggalJadwal: {
        type: Date,
        required: true,
        // default: 'No description provided.'
    },

    status: {
        type: String,
        required: true,
        // default: 'No description provided.'
    },
}, {
    // Schema Options (Optional, but useful)
    timestamps: true // Adds two fields: 'createdAt' and 'updatedAt' automatically
});

// 2. Create the Model
// A Mongoose Model is a class used to construct documents 
// and interact with the MongoDB database collection.
const JadwalPerawatan = mongoose.model('jadwalPerawatan', Schema);

// 3. Export the Model
module.exports = JadwalPerawatan;